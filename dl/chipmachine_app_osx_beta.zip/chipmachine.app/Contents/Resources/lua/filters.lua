

FILTERS = {
	name = "MODS",
	ext = "mod,s3m,it,xm,ft",
	color = 0x5555cc
}