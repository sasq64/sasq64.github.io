#ifndef __C2MAN__
#include <stdio.h>
#include <stdlib.h>
#include <png.h>

static png_structp ps;
static png_infop pi;

#endif

/* Load a picture in PNG format */
void *load_png(char *fname, /*Name of picture file */
				   int *width, /* Width of picture */
				   int *height, /* Height of picture */
				   int *fmt /* Format of picture. Can be:
							   3 - For 3 bytes per pixel RGB
							   4 - For 4 bytes per pixel RGBA
							   1 - For 4 bytes per pixel RGBA with 1 bit alpha */)
{
   	FILE *fp;
   	int type, bpc;
   	void **row = NULL;
   	void *pic = NULL;
   
    ps = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    pi = png_create_info_struct(ps);

	if((fp = fopen(fname, "rb"))) {
	  	png_init_io(ps, fp);
   		png_read_info(ps, pi);
        *width  = png_get_image_width(ps, pi);
        *height = png_get_image_height(ps, pi);
	   	bpc = png_get_bit_depth(ps, pi);
		if(bpc != 8)
			return NULL;
		type = png_get_color_type(ps, pi);
	   	switch(type) {
		 case PNG_COLOR_TYPE_GRAY:
		   *fmt = 1;
		   break;
		 case PNG_COLOR_TYPE_RGB:
		   *fmt = 3;
		   break;
		 case PNG_COLOR_TYPE_RGB_ALPHA:
		   *fmt = 4;
		   break;
		 default:
		   /* Unsupported */
		   *fmt = 0;
		   return NULL;
		   break;
		}
	   
        if((pic = malloc(*fmt * (*width) * (*height))) != NULL) {
			if((row = malloc((*height) * sizeof (void *))) != NULL) {
          		int i;
                for(i = 0; i < *height; i++)
                	row[i] = (char *)pic + i * png_get_rowbytes(ps, pi);
                png_read_image(ps, (png_bytepp)row);
                free(row);
            } else {
			   free(pic);
			   pic = NULL;
			}
        }	   
	   	fclose(fp);
	}
   	return pic;
}

/* Save a picture in PNG format */
void save_png(char *fname, unsigned char *pic, /* Pointer to raw pixels */
			  int width, int height)
{
   	FILE *fp;
   	int i;
   	png_byte **rows = malloc(sizeof(png_byte *) * height);
    ps = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    pi = png_create_info_struct(ps);

	if((fp = fopen(fname, "wb"))) {
		png_init_io(ps, fp);
	   	png_set_IHDR(ps, pi, width, height, 8, PNG_COLOR_TYPE_RGB,
					 PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT,
					 PNG_FILTER_TYPE_DEFAULT);
	   	for(i=0; i< height; i++)
			rows[(height-1)-i] = &pic[i*width*3];
	   	png_write_info(ps, pi);
		png_write_image(ps, rows);
	    png_write_end(ps, pi);
	   	free(rows);
	   	fclose(fp);
	}
   
}
