##### GBTiler Readme by Sasq/O2 ######



WHAT IS IT?
-----------

GBTiler is a small utility to split a PNG-picture into tiles suitable for use
with Gameboy (Color) programs. GBTiler is released under GPL (GNU Public License).
Dont complain on the my assembler-source, I'm new to z80!
For more info, run "gbtiler -h".


HOW DOES IT WORK?
-----------------

Basically, the process is this:

1. Read the png-file and decide how many 8x8 tiles to split it into.

2. Check the colors in each tile - if more than 4 an error is generated.

3. If 4 or less, the colors are checked against the current list of palettes.
   If the colors match a palette, the tile will use it, otherwise a new palette
   will be created.

4. If maximum number of palettes is reached (typically 8) an error is generated.

5. When all tiles have been split and each uses one of the (up to 8) palettes,
   the tiles are compared to eliminate any tiles that are equal.

6. Now the generated data can be written to disk. Three different files can
   be generated;
   - One containing the raw pixels of all tiles in gameboy-format.
   - One containg a byte-map of tile-indexes + a byte-map of palette-indexes to
     indicate which tile and which palette to use at each screen-position.
   - One file containing the palettes.
   
Thats about it!



THE FILEFORMATS PLEASE!
-----------------------

The tilefile (tiles.bin)
  Starts with a 16bit (little endian) word indicating the number of tiles and then
  all tiles follow at 16 bytes per tile in native GB format.
  
The mapfile (tilemap.bin)
  Starts with two bytes indicating width and height of the map. Then width*height
  palette-indexes follows (can be written directly into vbank 1) followed by
  another width*height of tile-indexes (written to same adress but in vbank 0).
  
The palettefile (palettes.bin)
  Stars with a byte indicating number of palettes, then the palettes follow with
  8 bytes per palette (4 colors, 2 byte per color). They are ordered so they can
  be written sequentially into $FF69 when autoincrement is on ($FF68).
  
Feel free to use the code in test.asm for reading your data!


TESTING
-------

TO generate the files needed by MAKE.BAT to compile the gameboy-cart, use
"gbtiler -fT -fM -fP -b <picture>"



COMPILING
---------

The include Makefile.w32 requires Visual C++ and libpng and libz to
compile.
I have not compiled it for linux yet but that shouldn't be any problem.
The GB example source is compiled through MAKE.BAT (uses RGBASM).



TODO
----

- Handle closest-matching colors
- Different fileformats (like GBR, GBDK & RGBASM source)
- Metatiles



CONTACT
-------

Mail me at jonas@upright.se (or catch men on IRC (Efnet) as "Sasq")


