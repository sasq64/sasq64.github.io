void *load_png(char *fname, int *width, int *height, int *fmt);
void save_png(char *fname, unsigned char *pic, int width, int height);

