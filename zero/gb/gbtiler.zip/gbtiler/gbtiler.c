/* GBTiler v1.0beta by Sasq/O2
 * GBTiler is released under GPL
 */

#include <stdio.h>
#include <stdlib.h>
#include "png_load.h"

/* Tile width and height (Pretty hardcoded right now so dont change) */
int tilew = 8;
int tileh = 8;

typedef struct {
	unsigned char ncols;
	unsigned short colors[4];
} Palette;

typedef struct {
	int pal;
	unsigned short checksum;
	unsigned short data[8];
} Tile;

typedef struct {
	unsigned char tile;
	unsigned char pal;
} TileIndex;

/* Return a printable string from a palette */
char *pal2str(char *str, Palette *pal)
{
	int i;
	char tmp[32];
	strcpy(str, "[ ");
	for(i=0; i< pal->ncols; i++) {
		sprintf(tmp, "%04x ", pal->colors[i]&0xffff);
		strcat(str, tmp);
	}
	strcat(str, " ]");
	return str;	
}


void dump_palettes(char *fname, Palette *pals, int n, int flags)
{
	int i,j;
	unsigned char pn = n;
	FILE *fp = fopen(fname, "wb");
	if(fp) {
		fwrite(&pn, 1, 1, fp);		
		for(i=0; i<n; i++)
			for(j=0; j<4; j++) {
				pn = pals[i].colors[j]&0xff;
				fwrite(&pn, 1, 1, fp);
				pn = pals[i].colors[j]>>8;
				fwrite(&pn, 1, 1, fp);
			}
		fclose(fp);
	}
}

void dump_tiles(char *fname, Tile *tiles, int n, int flags)
{
	int i;
	unsigned char pn = 0;
	FILE *fp = fopen(fname, "wb");
	if(fp) {
		pn = n&0xff;
		fwrite(&pn, 1, 1, fp);
		pn = n>>8;
		fwrite(&pn, 1, 1, fp);
		for(i=0; i<n; i++)
			fwrite(tiles[i].data, 8 * sizeof(unsigned short), 1, fp);
		fclose(fp);
	}
}

void dump_map(char *fname, TileIndex *index, int w, int h, int flags)
{
	int i;
	unsigned char pn = 0;
	FILE *fp = fopen(fname, "wb");
	if(fp) {
		pn = w&0xff;
		fwrite(&pn, 1, 1, fp);
		pn = h&0xff;
		fwrite(&pn, 1, 1, fp);
		for(i=0; i<w*h; i++)
			fwrite(&index[i].pal, sizeof(unsigned char), 1, fp);
		for(i=0; i<w*h; i++)
			fwrite(&index[i].tile, sizeof(unsigned char), 1, fp);
		fclose(fp);
	}
}


/* Check to see if src palette matches dest, possibly adding colors to dest. Returns 0 if they
   can not be matched, 1 for match through changing, 2 for direct match */
int check_palette(Palette *src, Palette *dst)
{
	int i,j;
	int match = 0;
	unsigned short unmatched[4];
	int um = 0;
	for(i=0; i<src->ncols; i++) {
		for(match=0, j=0; j<dst->ncols; j++) {
			if(src->colors[i] == dst->colors[j])
				match = 1;
		}
		if(!match) {
			unmatched[um++] = src->colors[i];
		}
	}

	if(!um)
		return 2;
		
	if(um > 4-dst->ncols)
		return 0;

	for(i=0; i<um; i++)
		dst->colors[dst->ncols+i] = unmatched[i];
	dst->ncols += um;	
	return 1;
}


/* Check if color is in palette, otherwise extend palette. Returns 0 if palette is full */
int check_color(int col, Palette *pal)
{
	int i;
	/* Check against earlier found colors */
	for(i=0; i<pal->ncols; i++) {
		if(col == pal->colors[i])
			i = 99;
	}
	if(i<99) { /* No color found */
		if(pal->ncols > 3)
			return 0;
		else
			pal->colors[pal->ncols++] = col;
		return 1;
	}
	return 2;
}


void set_tile_pixel(Tile *t, int x, int y, int i)
{
	
	int m = ((i&2)<<(14-x)) | ((i&1)<<(7-x));
	
	t->data[y] &= ~m;
	t->data[y] |= m;
}

int get_tile_pixel(Tile *t, int x, int y)
{
	return ((t->data[y]>>(14-x))&2) | ((t->data[y]>>(7-x))&1);
}


Tile *make_tile(Tile *t, int w, int h, Palette *pal, unsigned short *pixels, int palnum)
{
	int x,y,i;
	unsigned short *ptr = pixels;
	for(y=0; y<h; y++)  {
		for(x=0; x<w; x++, ptr++) {
			for(i=0; i<pal->ncols; i++)
				if(*ptr == pal->colors[i]) {
					set_tile_pixel(t, x, y, i);
				}
		}
	}

	t->pal = palnum;

	/* Calculate tile checksum */
	t->checksum = 0;
	for(i=0; i<16; i++)
		t->checksum += ((unsigned char *)t->data)[i];

	return t;
}

/* Remove tile number 'remn' from tile-list, replacing it with 'subst'.
   Replaces all references in index with subst.
   Renumbers all references in index that points to tiles after removed.
   total = number of tiles & itotal = number of indexes
*/
void remove_tile(Tile *tiles, TileIndex *indexes, int remn, int subst, int total, int itotal)
{
	int i;

	/* Remove tile and copy trailing to lower adress */
	memcpy(&tiles[remn], &tiles[remn+1], sizeof(Tile) * (total-remn-1));

	/* Remap indexes */
	for(i=0; i<itotal; i++) {
		if(indexes[i].tile == remn)
			indexes[i].tile = subst;
		if(indexes[i].tile > remn)
			indexes[i].tile--;
	}
}


void print_tile(Tile *t)
{
	char *tilechar = ":*%#";
	int i,j;
	return;
	printf("\n");
	for(j=0; j<8; j++) {
		for(i=0; i<8; i++)
			printf("%c", tilechar[get_tile_pixel(t, i, j)]);
		printf("\n");
	}
	printf("\n");
}


int main(int argc, char **argv)
{
	int xtiles = 0;
	int ytiles = 0;
	char *fname = NULL;
	char *tilefile = NULL;
	char *mapfile = NULL;
	char *palfile = NULL;
	int quiet = 0;
	int eliminate = 1;
	int max_pals = 8;
	int blank = 0;

	int x,y,ix,iy;
	int w,h,f,i,j;
	int total;
	TileIndex *indexmap;
	unsigned int col;
	unsigned char *tilep;
	unsigned char *pic;
	unsigned short *tilepixels, *pixelp;
	int empty=0;

	Tile *map, *t;
	Palette *pals;
	int numpal = 0;
	
	for(i=1; i<argc; i++) {
		if(argv[i][0] == '-')
			switch(argv[i][1]) {
				case 'x':
					xtiles = atoi(&argv[i][2]);
					break;
				case 'y':
					ytiles = atoi(&argv[i][2]);
					break;
				case 'h':
					printf("GBTiler v1.0beta - by Sasq/O2 [jonas@upright.se]\n\n");
					printf("Splits a PNG-picture into 8x8 tiles in gameboy format. Also eliminates\n");
					printf("similar tiles and finds palettes for all tiles. Intended use is both for\n");
					printf("converting whole pictures as well as tilesets for maps.\n\n");
					printf("Usage: %s [options] <pngfile>\n", argv[0]);
					printf("-x<num>     Number of tiles to extract in x-direction (default: Whole width)\n");
					printf("-y<num>     Number of tiles to extract in y-direction (default: Whole height)\n");
					printf("-p<num>     Maximum number of palettes allowed in the picture (default: 8)\n");
					printf("-fT<file>   Dump tilegraphics to this file\n");
					printf("-fM<file>   Dump tilemap (indexes of tiles) to this file\n");
					printf("-fP<file>   Dump palettes to this file\n");
					printf("-q          Quiet mode\n");
					printf("-b          Put blank tile in position 0\n");
					printf("-s          Don't eliminate similar tiles\n\n");
					exit(0);
					break;
				case 'p':
					max_pals = atoi(&argv[i][2]);
					break;
				case 'q':
					quiet = 1;
					break;
				case 'b':
					blank = 1;
					break;
				case 's':
					eliminate = 0;
					break;
				case 'f':
					switch(argv[i][2]) {
						case 'T':
							if(argv[i][3])
								tilefile = &argv[i][3];
							else
								tilefile = "tiles.bin";
							break;
						case 'M':
							if(argv[i][3])
								mapfile = &argv[i][3];
							else
								mapfile = "tilemap.bin";
							break;
						case 'P':
							if(argv[i][3])
								palfile = &argv[i][3];
							else
								palfile = "palettes.bin";
							break;
					}
					break;
				default:
					fprintf(stderr, "\n**Error: Unknown option '-%c', use '-h' for help\n", argv[i][1]);
					exit(0);
					break;
			}
		else
			fname = argv[i];
	}
	if(fname) {
		if(!(pic = load_png(fname, &w, &h, &f))) {
			fprintf(stderr, "**Error: Could not open \"%s\"\n", fname);
			exit(0);	
		}
		
	} else {
		fprintf(stderr, "**Error: No PNG-file specified\n");
		exit(0);
	}
	if(!xtiles)
		xtiles = w/tilew;
	if(!ytiles)
		ytiles = h/tileh;
		
	if(!quiet)
		printf("Input picture is %dx%d pixels\nSplitting into %dx%d tiles\n", w, h, xtiles, ytiles);
	
	tilepixels = malloc(sizeof(unsigned short) * tilew * tileh);
	pals = malloc(sizeof(Palette) * max_pals);
	map = malloc(sizeof(Tile) * (xtiles * ytiles + blank));
	memset(map, 0, sizeof(Tile) * xtiles * ytiles);

	for(iy=0; iy<ytiles; iy++) {
		for(ix=0; ix<xtiles; ix++) {
			Palette pal;
			pal.ncols = 0;

			tilep = &pic[ix*f*tilew + iy*w*f*tileh];
			pixelp = tilepixels;
			/* Build palette from tile */
			for(y=0; y<tileh; y++, tilep += ((w-tilew)*f)) {
				for(x=0; x<tilew; x++, tilep+=f) {

					/* Get color at current pixel in tile */
					col = ((tilep[2]>>3)<<10) | ((tilep[1]>>3)<<5) | (tilep[0]>>3);
					*pixelp++ = col;
					if(!check_color(col, &pal)) {
							fprintf(stderr, "**Error: Too many colors in tile at (%d,%d)!\n", ix, iy);
							exit(0);
					}
				}
			}
			/* Check tile-palette against global list of palettes */	
			for(i=0, j=0; i<numpal && !j; i++) {
				if(j = check_palette(&pal, &pals[i]))
					pal = pals[i];
			}
			/*if(j == 1) {
				printf("Extending palette %d to %s\n", i-1, pal2str(s1, &pal));
			}*/
			if(j == 0) {
				/*printf("Creating new palette %d = %s\n", numpal, pal2str(s1, &pal));*/
				if(numpal == 8) {
					fprintf(stderr, "**Error: Max palettes reached in tile at (%d,%d)!\n", ix, iy);
					exit(0);
				}
				pals[numpal++] = pal;
				i = numpal;
			}
			
			make_tile(t = &map[(ix+iy*xtiles)+blank], tilew, tileh, &pal, tilepixels, i-1);
			if(!t->checksum)
				empty++;
			print_tile(t);
		}
	}

	total = xtiles*ytiles;
	indexmap = malloc(total * sizeof(TileIndex));
	for(i=0; i<total; i++) {
		indexmap[i].tile = i+blank;
		indexmap[i].pal = map[i+blank].pal;
	}
	total += blank;
	if(eliminate) {
		if(!quiet)
			printf("Eliminating tiles...\n");
		/* Strip away similar tiles */
		for(i=0; i<total; i++)
			for(j=i+1; j<total; j++) {
				if(map[i].checksum == map[j].checksum) {
					for(x=0; x<8 && map[i].data[x] == map[j].data[x]; x++);
					if(x == 8) {
						remove_tile(map, indexmap, j, i, total, xtiles*ytiles);
						/*printf("Removing tile %d (similar to %d)\n", j, i);*/
						total--;
						j--;
					}
				}
			}
		if(!quiet)
			printf("%d tiles eliminated\n", xtiles*ytiles-total);
	}
	
	if(tilefile) {
		if(!quiet)
			printf("Dumping %d tiles to \"%s\"...\n", total, tilefile);
		dump_tiles(tilefile, map, total, 0);
	}
	if(mapfile) {
		if(!quiet)
			printf("Dumping tilemap with %dx%d indexes to \"%s\"...\n", xtiles, ytiles, mapfile);
		dump_map(mapfile, indexmap, xtiles, ytiles, 0);
	}
	if(palfile) {
		if(!quiet)
			printf("Dumping %d palettes to \"%s\"...\n", numpal, palfile);
		dump_palettes(palfile, pals, numpal, 0);
	}
	if(!quiet)
		printf("Operation complete!\n");
	return 0;
}
